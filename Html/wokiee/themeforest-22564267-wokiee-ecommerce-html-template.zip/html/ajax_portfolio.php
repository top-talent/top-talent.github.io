  <?php
  echo '<div class="element-item sort-value-02">
                       <figure>
                            <img src="images/portfolio/portfolio-col-grid-four-img-01.jpg" alt="">
                            <figcaption>
                                <h6 class="tt-title"><a href="#">TITLE</a></h6>
                                <p>
                                    Lorem ipsum dolor sit amet cons.
                                </p>
                                <a href="images/portfolio/portfolio-col-grid-four-img-01.jpg" class="tt-btn-zomm"></a>
                            </figcaption>
                        </figure>
                    </div>';
?>