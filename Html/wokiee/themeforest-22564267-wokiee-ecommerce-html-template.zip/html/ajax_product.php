  <?php
  echo '<div class="col-6 col-md-4 tt-col-item">
                              <div class="tt-product thumbprod-center">
                                                                <a href="product.html">
                                                                    <div class="tt-image-box">
                                                                        <span class="tt-img"><img src="images/product/product-01.jpg" alt=""></span>
                                                                        <span class="tt-img-roll-over"><img src="images/product/product-01-02.jpg" alt=""></span>
                                                                    </div>
                                                                    <div class="tt-description">
                                                                        <h2 class="tt-title">Flared Shift Dress</h2>
                                                                        <div class="tt-price">
                                                                            <span class="new-price">$14</span>
                                                                            <span class="old-price">$24</span>
                                                                        </div>
                                                                        <div class="tt-product-inside-hover">
                                                                            <div class="tt-btn-addtocart" data-toggle="modal" data-target="#modalAddToCartProduct">ADD TO CART</div>
                                                                            <div class="tt-btn-quickview" data-toggle="modal" data-target="#ModalquickView"></div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </div>
                            </div>';
?>